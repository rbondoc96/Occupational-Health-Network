--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cldb;
--
-- Name: cldb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cldb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE cldb OWNER TO postgres;

\connect cldb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: locator_authmethod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_authmethod (
    id integer NOT NULL,
    name character varying(16) NOT NULL
);


ALTER TABLE public.locator_authmethod OWNER TO postgres;

--
-- Name: locator_authcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_authcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_authcategory_id_seq OWNER TO postgres;

--
-- Name: locator_authcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_authcategory_id_seq OWNED BY public.locator_authmethod.id;


--
-- Name: locator_servicecategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_servicecategory (
    id integer NOT NULL,
    name character varying(30) NOT NULL
);


ALTER TABLE public.locator_servicecategory OWNER TO postgres;

--
-- Name: locator_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_categories_id_seq OWNER TO postgres;

--
-- Name: locator_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_categories_id_seq OWNED BY public.locator_servicecategory.id;


--
-- Name: locator_ccfcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_ccfcategory (
    id integer NOT NULL,
    name character varying(16) NOT NULL
);


ALTER TABLE public.locator_ccfcategory OWNER TO postgres;

--
-- Name: locator_ccfcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_ccfcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_ccfcategory_id_seq OWNER TO postgres;

--
-- Name: locator_ccfcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_ccfcategory_id_seq OWNED BY public.locator_ccfcategory.id;


--
-- Name: locator_contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_contacts (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(30),
    email character varying(254),
    phone character varying(25),
    location_id integer NOT NULL
);


ALTER TABLE public.locator_contacts OWNER TO postgres;

--
-- Name: locator_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_contacts_id_seq OWNER TO postgres;

--
-- Name: locator_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_contacts_id_seq OWNED BY public.locator_contacts.id;


--
-- Name: locator_daytimerange; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_daytimerange (
    id integer NOT NULL,
    day character varying(3) NOT NULL,
    location_id integer NOT NULL,
    end_am_pm character varying(2) NOT NULL,
    end_hour character varying(2) NOT NULL,
    end_min character varying(2) NOT NULL,
    start_am_pm character varying(2) NOT NULL,
    start_min character varying(2) NOT NULL,
    start_hour character varying(2) NOT NULL
);


ALTER TABLE public.locator_daytimerange OWNER TO postgres;

--
-- Name: locator_daytimerange_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_daytimerange_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_daytimerange_id_seq OWNER TO postgres;

--
-- Name: locator_daytimerange_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_daytimerange_id_seq OWNED BY public.locator_daytimerange.id;


--
-- Name: locator_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_location (
    id integer NOT NULL,
    name character varying(70) NOT NULL,
    branch_name character varying(30),
    street_line_1 character varying(50) NOT NULL,
    street_line_2 character varying(35),
    city character varying(45) NOT NULL,
    state character varying(2) NOT NULL,
    zipcode character varying(10) NOT NULL,
    comments text,
    last_updated date NOT NULL,
    location_category_id integer,
    fax character varying(14),
    phone character varying(25) NOT NULL,
    website text,
    is_phone_callable boolean NOT NULL,
    last_verified date
);


ALTER TABLE public.locator_location OWNER TO postgres;

--
-- Name: locator_location_auth_method_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_location_auth_method_list (
    id integer NOT NULL,
    location_id integer NOT NULL,
    authmethod_id integer NOT NULL
);


ALTER TABLE public.locator_location_auth_method_list OWNER TO postgres;

--
-- Name: locator_location_auth_method_list_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_location_auth_method_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_location_auth_method_list_id_seq OWNER TO postgres;

--
-- Name: locator_location_auth_method_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_location_auth_method_list_id_seq OWNED BY public.locator_location_auth_method_list.id;


--
-- Name: locator_location_ccf_category_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_location_ccf_category_list (
    id integer NOT NULL,
    location_id integer NOT NULL,
    ccfcategory_id integer NOT NULL
);


ALTER TABLE public.locator_location_ccf_category_list OWNER TO postgres;

--
-- Name: locator_location_ccf_category_list_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_location_ccf_category_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_location_ccf_category_list_id_seq OWNER TO postgres;

--
-- Name: locator_location_ccf_category_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_location_ccf_category_list_id_seq OWNED BY public.locator_location_ccf_category_list.id;


--
-- Name: locator_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_location_id_seq OWNER TO postgres;

--
-- Name: locator_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_location_id_seq OWNED BY public.locator_location.id;


--
-- Name: locator_location_service_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_location_service_list (
    id integer NOT NULL,
    location_id integer NOT NULL,
    service_id integer NOT NULL
);


ALTER TABLE public.locator_location_service_list OWNER TO postgres;

--
-- Name: locator_location_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_location_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_location_services_id_seq OWNER TO postgres;

--
-- Name: locator_location_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_location_services_id_seq OWNED BY public.locator_location_service_list.id;


--
-- Name: locator_locationcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_locationcategory (
    id integer NOT NULL,
    name character varying(40) NOT NULL
);


ALTER TABLE public.locator_locationcategory OWNER TO postgres;

--
-- Name: locator_locationcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_locationcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_locationcategory_id_seq OWNER TO postgres;

--
-- Name: locator_locationcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_locationcategory_id_seq OWNED BY public.locator_locationcategory.id;


--
-- Name: locator_rating; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_rating (
    id integer NOT NULL,
    down_votes integer NOT NULL,
    location_id integer NOT NULL,
    comments character varying(255) NOT NULL,
    date_submitted date NOT NULL,
    up_votes integer NOT NULL
);


ALTER TABLE public.locator_rating OWNER TO postgres;

--
-- Name: locator_rating_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_rating_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_rating_id_seq OWNER TO postgres;

--
-- Name: locator_rating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_rating_id_seq OWNED BY public.locator_rating.id;


--
-- Name: locator_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_service (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    service_category_id integer,
    simple_name character varying(15)
);


ALTER TABLE public.locator_service OWNER TO postgres;

--
-- Name: locator_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_service_id_seq OWNER TO postgres;

--
-- Name: locator_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_service_id_seq OWNED BY public.locator_service.id;


--
-- Name: locator_servicetimerange; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locator_servicetimerange (
    id integer NOT NULL,
    name character varying(30) NOT NULL,
    location_id integer NOT NULL,
    end_am_pm character varying(2) NOT NULL,
    end_hour character varying(2) NOT NULL,
    end_min character varying(2) NOT NULL,
    start_am_pm character varying(2) NOT NULL,
    start_hour character varying(2) NOT NULL,
    start_min character varying(2) NOT NULL
);


ALTER TABLE public.locator_servicetimerange OWNER TO postgres;

--
-- Name: locator_servicetimerange_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locator_servicetimerange_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locator_servicetimerange_id_seq OWNER TO postgres;

--
-- Name: locator_servicetimerange_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locator_servicetimerange_id_seq OWNED BY public.locator_servicetimerange.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: locator_authmethod id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_authmethod ALTER COLUMN id SET DEFAULT nextval('public.locator_authcategory_id_seq'::regclass);


--
-- Name: locator_ccfcategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_ccfcategory ALTER COLUMN id SET DEFAULT nextval('public.locator_ccfcategory_id_seq'::regclass);


--
-- Name: locator_contacts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_contacts ALTER COLUMN id SET DEFAULT nextval('public.locator_contacts_id_seq'::regclass);


--
-- Name: locator_daytimerange id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_daytimerange ALTER COLUMN id SET DEFAULT nextval('public.locator_daytimerange_id_seq'::regclass);


--
-- Name: locator_location id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location ALTER COLUMN id SET DEFAULT nextval('public.locator_location_id_seq'::regclass);


--
-- Name: locator_location_auth_method_list id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_auth_method_list ALTER COLUMN id SET DEFAULT nextval('public.locator_location_auth_method_list_id_seq'::regclass);


--
-- Name: locator_location_ccf_category_list id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_ccf_category_list ALTER COLUMN id SET DEFAULT nextval('public.locator_location_ccf_category_list_id_seq'::regclass);


--
-- Name: locator_location_service_list id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_service_list ALTER COLUMN id SET DEFAULT nextval('public.locator_location_services_id_seq'::regclass);


--
-- Name: locator_locationcategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_locationcategory ALTER COLUMN id SET DEFAULT nextval('public.locator_locationcategory_id_seq'::regclass);


--
-- Name: locator_rating id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_rating ALTER COLUMN id SET DEFAULT nextval('public.locator_rating_id_seq'::regclass);


--
-- Name: locator_service id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_service ALTER COLUMN id SET DEFAULT nextval('public.locator_service_id_seq'::regclass);


--
-- Name: locator_servicecategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_servicecategory ALTER COLUMN id SET DEFAULT nextval('public.locator_categories_id_seq'::regclass);


--
-- Name: locator_servicetimerange id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_servicetimerange ALTER COLUMN id SET DEFAULT nextval('public.locator_servicetimerange_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3108.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3110.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3106.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3112.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3114.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3116.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3118.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3104.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3102.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3119.dat';

--
-- Data for Name: locator_authmethod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_authmethod (id, name) FROM stdin;
\.
COPY public.locator_authmethod (id, name) FROM '$$PATH$$/3137.dat';

--
-- Data for Name: locator_ccfcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_ccfcategory (id, name) FROM stdin;
\.
COPY public.locator_ccfcategory (id, name) FROM '$$PATH$$/3141.dat';

--
-- Data for Name: locator_contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_contacts (id, name, title, email, phone, location_id) FROM stdin;
\.
COPY public.locator_contacts (id, name, title, email, phone, location_id) FROM '$$PATH$$/3139.dat';

--
-- Data for Name: locator_daytimerange; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_daytimerange (id, day, location_id, end_am_pm, end_hour, end_min, start_am_pm, start_min, start_hour) FROM stdin;
\.
COPY public.locator_daytimerange (id, day, location_id, end_am_pm, end_hour, end_min, start_am_pm, start_min, start_hour) FROM '$$PATH$$/3133.dat';

--
-- Data for Name: locator_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_location (id, name, branch_name, street_line_1, street_line_2, city, state, zipcode, comments, last_updated, location_category_id, fax, phone, website, is_phone_callable, last_verified) FROM stdin;
\.
COPY public.locator_location (id, name, branch_name, street_line_1, street_line_2, city, state, zipcode, comments, last_updated, location_category_id, fax, phone, website, is_phone_callable, last_verified) FROM '$$PATH$$/3121.dat';

--
-- Data for Name: locator_location_auth_method_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_location_auth_method_list (id, location_id, authmethod_id) FROM stdin;
\.
COPY public.locator_location_auth_method_list (id, location_id, authmethod_id) FROM '$$PATH$$/3143.dat';

--
-- Data for Name: locator_location_ccf_category_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_location_ccf_category_list (id, location_id, ccfcategory_id) FROM stdin;
\.
COPY public.locator_location_ccf_category_list (id, location_id, ccfcategory_id) FROM '$$PATH$$/3145.dat';

--
-- Data for Name: locator_location_service_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_location_service_list (id, location_id, service_id) FROM stdin;
\.
COPY public.locator_location_service_list (id, location_id, service_id) FROM '$$PATH$$/3127.dat';

--
-- Data for Name: locator_locationcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_locationcategory (id, name) FROM stdin;
\.
COPY public.locator_locationcategory (id, name) FROM '$$PATH$$/3135.dat';

--
-- Data for Name: locator_rating; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_rating (id, down_votes, location_id, comments, date_submitted, up_votes) FROM stdin;
\.
COPY public.locator_rating (id, down_votes, location_id, comments, date_submitted, up_votes) FROM '$$PATH$$/3123.dat';

--
-- Data for Name: locator_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_service (id, name, service_category_id, simple_name) FROM stdin;
\.
COPY public.locator_service (id, name, service_category_id, simple_name) FROM '$$PATH$$/3125.dat';

--
-- Data for Name: locator_servicecategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_servicecategory (id, name) FROM stdin;
\.
COPY public.locator_servicecategory (id, name) FROM '$$PATH$$/3129.dat';

--
-- Data for Name: locator_servicetimerange; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locator_servicetimerange (id, name, location_id, end_am_pm, end_hour, end_min, start_am_pm, start_hour, start_min) FROM stdin;
\.
COPY public.locator_servicetimerange (id, name, location_id, end_am_pm, end_hour, end_min, start_am_pm, start_hour, start_min) FROM '$$PATH$$/3131.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 92, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 112, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 19, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 43, true);


--
-- Name: locator_authcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_authcategory_id_seq', 5, true);


--
-- Name: locator_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_categories_id_seq', 9, true);


--
-- Name: locator_ccfcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_ccfcategory_id_seq', 4, true);


--
-- Name: locator_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_contacts_id_seq', 1, false);


--
-- Name: locator_daytimerange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_daytimerange_id_seq', 1, false);


--
-- Name: locator_location_auth_method_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_location_auth_method_list_id_seq', 1, false);


--
-- Name: locator_location_ccf_category_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_location_ccf_category_list_id_seq', 1, false);


--
-- Name: locator_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_location_id_seq', 1, false);


--
-- Name: locator_location_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_location_services_id_seq', 1, false);


--
-- Name: locator_locationcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_locationcategory_id_seq', 7, true);


--
-- Name: locator_rating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_rating_id_seq', 1, false);


--
-- Name: locator_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_service_id_seq', 31, true);


--
-- Name: locator_servicetimerange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locator_servicetimerange_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: locator_location location_name_branch_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location
    ADD CONSTRAINT location_name_branch_name_key UNIQUE (name, branch_name);


--
-- Name: locator_authmethod locator_authcategory_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_authmethod
    ADD CONSTRAINT locator_authcategory_name_key UNIQUE (name);


--
-- Name: locator_authmethod locator_authcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_authmethod
    ADD CONSTRAINT locator_authcategory_pkey PRIMARY KEY (id);


--
-- Name: locator_servicecategory locator_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_servicecategory
    ADD CONSTRAINT locator_categories_pkey PRIMARY KEY (id);


--
-- Name: locator_ccfcategory locator_ccfcategory_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_ccfcategory
    ADD CONSTRAINT locator_ccfcategory_name_key UNIQUE (name);


--
-- Name: locator_ccfcategory locator_ccfcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_ccfcategory
    ADD CONSTRAINT locator_ccfcategory_pkey PRIMARY KEY (id);


--
-- Name: locator_contacts locator_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_contacts
    ADD CONSTRAINT locator_contacts_pkey PRIMARY KEY (id);


--
-- Name: locator_daytimerange locator_daytimerange_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_daytimerange
    ADD CONSTRAINT locator_daytimerange_pkey PRIMARY KEY (id);


--
-- Name: locator_location_auth_method_list locator_location_auth_me_location_id_authmethod_i_ca6220fd_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_auth_method_list
    ADD CONSTRAINT locator_location_auth_me_location_id_authmethod_i_ca6220fd_uniq UNIQUE (location_id, authmethod_id);


--
-- Name: locator_location_auth_method_list locator_location_auth_method_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_auth_method_list
    ADD CONSTRAINT locator_location_auth_method_list_pkey PRIMARY KEY (id);


--
-- Name: locator_location_ccf_category_list locator_location_ccf_cat_location_id_ccfcategory__3bae71cc_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_ccf_category_list
    ADD CONSTRAINT locator_location_ccf_cat_location_id_ccfcategory__3bae71cc_uniq UNIQUE (location_id, ccfcategory_id);


--
-- Name: locator_location_ccf_category_list locator_location_ccf_category_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_ccf_category_list
    ADD CONSTRAINT locator_location_ccf_category_list_pkey PRIMARY KEY (id);


--
-- Name: locator_location locator_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location
    ADD CONSTRAINT locator_location_pkey PRIMARY KEY (id);


--
-- Name: locator_location_service_list locator_location_services_location_id_service_id_12cbb336_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_service_list
    ADD CONSTRAINT locator_location_services_location_id_service_id_12cbb336_uniq UNIQUE (location_id, service_id);


--
-- Name: locator_location_service_list locator_location_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_service_list
    ADD CONSTRAINT locator_location_services_pkey PRIMARY KEY (id);


--
-- Name: locator_locationcategory locator_locationcategory_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_locationcategory
    ADD CONSTRAINT locator_locationcategory_name_key UNIQUE (name);


--
-- Name: locator_locationcategory locator_locationcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_locationcategory
    ADD CONSTRAINT locator_locationcategory_pkey PRIMARY KEY (id);


--
-- Name: locator_rating locator_rating_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_rating
    ADD CONSTRAINT locator_rating_pkey PRIMARY KEY (id);


--
-- Name: locator_service locator_service_name_deefca5e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_service
    ADD CONSTRAINT locator_service_name_deefca5e_uniq UNIQUE (name);


--
-- Name: locator_service locator_service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_service
    ADD CONSTRAINT locator_service_pkey PRIMARY KEY (id);


--
-- Name: locator_servicecategory locator_servicecategory_name_363affa8_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_servicecategory
    ADD CONSTRAINT locator_servicecategory_name_363affa8_uniq UNIQUE (name);


--
-- Name: locator_servicetimerange locator_servicetimerange_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_servicetimerange
    ADD CONSTRAINT locator_servicetimerange_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: locator_authcategory_name_b8d52a86_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_authcategory_name_b8d52a86_like ON public.locator_authmethod USING btree (name varchar_pattern_ops);


--
-- Name: locator_ccfcategory_name_be16ecbd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_ccfcategory_name_be16ecbd_like ON public.locator_ccfcategory USING btree (name varchar_pattern_ops);


--
-- Name: locator_contacts_location_id_9830f19e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_contacts_location_id_9830f19e ON public.locator_contacts USING btree (location_id);


--
-- Name: locator_daytimerange_location_id_4f411bdb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_daytimerange_location_id_4f411bdb ON public.locator_daytimerange USING btree (location_id);


--
-- Name: locator_location_auth_method_list_authmethod_id_329c0e66; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_location_auth_method_list_authmethod_id_329c0e66 ON public.locator_location_auth_method_list USING btree (authmethod_id);


--
-- Name: locator_location_auth_method_list_location_id_d43fc470; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_location_auth_method_list_location_id_d43fc470 ON public.locator_location_auth_method_list USING btree (location_id);


--
-- Name: locator_location_ccf_category_list_ccfcategory_id_b009e740; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_location_ccf_category_list_ccfcategory_id_b009e740 ON public.locator_location_ccf_category_list USING btree (ccfcategory_id);


--
-- Name: locator_location_ccf_category_list_location_id_724009bc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_location_ccf_category_list_location_id_724009bc ON public.locator_location_ccf_category_list USING btree (location_id);


--
-- Name: locator_location_location_category_id_99c4fe5f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_location_location_category_id_99c4fe5f ON public.locator_location USING btree (location_category_id);


--
-- Name: locator_location_services_location_id_d949398b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_location_services_location_id_d949398b ON public.locator_location_service_list USING btree (location_id);


--
-- Name: locator_location_services_service_id_444d906d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_location_services_service_id_444d906d ON public.locator_location_service_list USING btree (service_id);


--
-- Name: locator_locationcategory_name_7a5a9d4f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_locationcategory_name_7a5a9d4f_like ON public.locator_locationcategory USING btree (name varchar_pattern_ops);


--
-- Name: locator_rating_location_id_5f2ebddb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_rating_location_id_5f2ebddb ON public.locator_rating USING btree (location_id);


--
-- Name: locator_service_name_deefca5e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_service_name_deefca5e_like ON public.locator_service USING btree (name varchar_pattern_ops);


--
-- Name: locator_service_service_category_id_2fd42a99; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_service_service_category_id_2fd42a99 ON public.locator_service USING btree (service_category_id);


--
-- Name: locator_servicecategory_name_363affa8_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_servicecategory_name_363affa8_like ON public.locator_servicecategory USING btree (name varchar_pattern_ops);


--
-- Name: locator_servicetimerange_location_id_901a186c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX locator_servicetimerange_location_id_901a186c ON public.locator_servicetimerange USING btree (location_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_contacts locator_contacts_location_id_9830f19e_fk_locator_location_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_contacts
    ADD CONSTRAINT locator_contacts_location_id_9830f19e_fk_locator_location_id FOREIGN KEY (location_id) REFERENCES public.locator_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_daytimerange locator_daytimerange_location_id_4f411bdb_fk_locator_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_daytimerange
    ADD CONSTRAINT locator_daytimerange_location_id_4f411bdb_fk_locator_l FOREIGN KEY (location_id) REFERENCES public.locator_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_location_auth_method_list locator_location_aut_authmethod_id_329c0e66_fk_locator_a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_auth_method_list
    ADD CONSTRAINT locator_location_aut_authmethod_id_329c0e66_fk_locator_a FOREIGN KEY (authmethod_id) REFERENCES public.locator_authmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_location_auth_method_list locator_location_aut_location_id_d43fc470_fk_locator_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_auth_method_list
    ADD CONSTRAINT locator_location_aut_location_id_d43fc470_fk_locator_l FOREIGN KEY (location_id) REFERENCES public.locator_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_location_ccf_category_list locator_location_ccf_ccfcategory_id_b009e740_fk_locator_c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_ccf_category_list
    ADD CONSTRAINT locator_location_ccf_ccfcategory_id_b009e740_fk_locator_c FOREIGN KEY (ccfcategory_id) REFERENCES public.locator_ccfcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_location_ccf_category_list locator_location_ccf_location_id_724009bc_fk_locator_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_ccf_category_list
    ADD CONSTRAINT locator_location_ccf_location_id_724009bc_fk_locator_l FOREIGN KEY (location_id) REFERENCES public.locator_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_location locator_location_location_category_id_99c4fe5f_fk_locator_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location
    ADD CONSTRAINT locator_location_location_category_id_99c4fe5f_fk_locator_l FOREIGN KEY (location_category_id) REFERENCES public.locator_locationcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_location_service_list locator_location_ser_location_id_dc4b19ac_fk_locator_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_service_list
    ADD CONSTRAINT locator_location_ser_location_id_dc4b19ac_fk_locator_l FOREIGN KEY (location_id) REFERENCES public.locator_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_location_service_list locator_location_ser_service_id_bf580505_fk_locator_s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_location_service_list
    ADD CONSTRAINT locator_location_ser_service_id_bf580505_fk_locator_s FOREIGN KEY (service_id) REFERENCES public.locator_service(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_rating locator_rating_location_id_5f2ebddb_fk_locator_location_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_rating
    ADD CONSTRAINT locator_rating_location_id_5f2ebddb_fk_locator_location_id FOREIGN KEY (location_id) REFERENCES public.locator_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_service locator_service_service_category_id_2fd42a99_fk_locator_s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_service
    ADD CONSTRAINT locator_service_service_category_id_2fd42a99_fk_locator_s FOREIGN KEY (service_category_id) REFERENCES public.locator_servicecategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: locator_servicetimerange locator_servicetimer_location_id_901a186c_fk_locator_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locator_servicetimerange
    ADD CONSTRAINT locator_servicetimer_location_id_901a186c_fk_locator_l FOREIGN KEY (location_id) REFERENCES public.locator_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

